package cell;

public class ground extends cell{

	//Ground type
}
