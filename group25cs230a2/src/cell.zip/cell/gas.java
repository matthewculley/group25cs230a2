package cell;

public class gas extends obstacles{

	private inventory inv;
	
	
}
