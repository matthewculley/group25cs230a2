package cell;
public class fire extends obstacles{

	private inventory inv;
	
	public void check() {
		if(inv.hvFire() == true) {
			// Not sure how to turn obstacle into ground type
		}
	}
}
