package cell;

public class wall extends cell{

	//Wall type
}
