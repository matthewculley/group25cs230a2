package cell;

/**
 * (Incomplete)
 * @author 
 * @version 1.0
 */

public class cell {

	private image sprite;
	private int xPos;
	private int yPos;
	
	public void update() {
		
	}
	
	public void draw() {
		
	}
	
	public int getXPos() {
		return xPos;
	}
	
	public int setXPos() {
		this.xPos = xPos;
	}
	
	public int getYPos() {
		return yPos;
	}
	
	public int setYPos() {
		this.yPos = yPos;
	}
	
	
	
}
