package cell;

public class door extends cell{

	public void checkPlayer() {
		
	}
	
	private void open() {
		//Change into ground tile
	}
}
