package cell;

public class obstacles extends cell{

	//private inventory itemReq;
	
	public void checkItem(boolean item) {
		if(item == true) {
			open();
		}
	}
	
	private void open() {
		//Change into ground tile
	}
	
}
